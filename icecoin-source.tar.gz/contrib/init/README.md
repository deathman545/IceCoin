Sample configuration files for:

SystemD: icecoind.service
Upstart: icecoind.conf
OpenRC:  icecoind.openrc
         icecoind.openrcconf
CentOS:  icecoind.init
OS X:    org.icecoin.icecoind.plist

have been made available to assist packagers in creating node packages here.

See doc/init.md for more information.
