
Debian
====================
This directory contains files used to package icecoind/icecoin-qt
for Debian-based Linux systems. If you compile icecoind/icecoin-qt yourself, there are some useful files here.

## icecoin: URI support ##


icecoin-qt.desktop  (Gnome / Open Desktop)
To install:

	sudo desktop-file-install icecoin-qt.desktop
	sudo update-desktop-database

If you build yourself, you will either need to modify the paths in
the .desktop file or copy or symlink your icecoin-qt binary to `/usr/bin`
and the `../../share/pixmaps/icecoin128.png` to `/usr/share/pixmaps`

icecoin-qt.protocol (KDE)

