#!/bin/bash
# use testnet settings,  if you need mainnet,  use ~/.icecoincore/icecoind.pid file instead
icecoin_pid=$(<~/.icecoincore/testnet3/icecoind.pid)
sudo gdb -batch -ex "source debug.gdb" icecoind ${icecoin_pid}
